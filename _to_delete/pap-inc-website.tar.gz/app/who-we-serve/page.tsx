import type { Metadata } from "next";
import { audiences } from "@/lib/content";
import PageHero from "@/components/PageHero";
import CtaBand from "@/components/CtaBand";

export const metadata: Metadata = { title: "Who We Serve" };

export default function WhoWeServe() {
  return (
    <>
      <PageHero
        title="Who We Serve"
        intro="We collaborate with government agencies, private equity organizations and corporations to facilitate change and achieve strong outcomes — and partner with professional services and technology providers to deliver specialized solutions."
      />
      <section className="section">
        <div className="container">
          {audiences.map((a) => (
            <div className="audience" key={a.label}>
              <div className="label">{a.label}</div>
              <div>
                <h2 style={{ fontSize: "1.8rem" }}>{a.heading}</h2>
                <p className="lead" style={{ maxWidth: "none" }}>{a.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
