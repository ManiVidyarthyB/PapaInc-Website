import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/content";

export const metadata: Metadata = { title: "Terms and Conditions" };

// NOTE: Placeholder copy. Replace with the terms from your current site / legal counsel.
export default function Page() {
  return (
    <LegalPage title="Terms and Conditions">
      <p>By accessing this website you agree to these terms. Content on this site is provided for general information only and does not constitute professional advice.</p>
      <h2>Use of content</h2>
      <p>All content is the property of {site.name} unless otherwise noted and may not be reproduced without permission.</p>
      <h2>Limitation of liability</h2>
      <p>{site.name} is not liable for any damages arising from the use of this website or reliance on its content.</p>
      <h2>Contact</h2>
      <p>{site.address.line1}, {site.address.line2} · {site.phone}</p>
    </LegalPage>
  );
}
