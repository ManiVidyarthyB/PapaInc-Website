import type { Metadata } from "next";
import { aLaCarte, packs, site } from "@/lib/content";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";

export const metadata: Metadata = { title: "Business Services" };

export default function BusinessServices() {
  return (
    <>
      <PageHero title="Small Business Services Menu" crumb="Business Services" eyebrow="Business Services"
        intro="Packaged support to build the policies, financials and strategy your small business needs to grow." />
      <section className="section section-soft">
        <div className="container grid grid-3" style={{ alignItems: "stretch" }}>
          {packs.map((p) => (
            <div className={`card pack ${p.featured ? "featured" : ""}`} key={p.name}>
              {p.featured && <span className="badge">Most Popular</span>}
              <h3>{p.name}</h3>
              <div className="includes">{p.includes ?? "The foundation for every business"}</div>
              {p.groups.map((g) => (
                <div key={g.title}>
                  <h4>{g.title}</h4>
                  <ul className="checklist">{g.items.map((i) => <li key={i}>{i}</li>)}</ul>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>
      <section className="section">
        <div className="container split" style={{ alignItems: "start" }}>
          <div>
            <span className="eyebrow">À La Carte</span>
            <h2>Individual services</h2>
            <p className="lead">Need something specific? Choose from our standalone services.</p>
          </div>
          <ul className="checklist" style={{ fontSize: "1.1rem" }}>
            {aLaCarte.map((i) => <li key={i}>{i}</li>)}
          </ul>
        </div>
      </section>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="cta-band">
            <div>
              <h2>Call to schedule your FREE consult</h2>
              <p>The Benchmark of Quality</p>
            </div>
            <a href={`tel:${site.phone.replace(/-/g, "")}`} className="btn"><Icon name="phone" size={18} /> {site.phone}</a>
          </div>
        </div>
      </section>
    </>
  );
}
