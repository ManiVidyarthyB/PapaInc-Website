import type { MetadataRoute } from "next";
import { articles } from "@/lib/insights";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://pap-inc.com";
  const pages = ["", "/what-we-do", "/who-we-serve", "/about", "/careers", "/contact-us", "/insights", "/business-services",
    "/government-services", "/healthcare", "/financial-business", "/privacy-policy", "/terms-and-conditions"];
  return [...pages.map((p) => ({ url: base + p })), ...articles.map((a) => ({ url: `${base}/insights/${a.slug}` }))];
}
