import type { Metadata } from "next";
import Link from "next/link";
import { articles } from "@/lib/insights";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";

export const metadata: Metadata = { title: "Insights" };

const fmt = (d: string) => new Date(d + "T00:00:00").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });

export default function Insights() {
  return (
    <>
      <PageHero title="Insights" intro="Perspectives from our consultants on talent, disaster recovery, compliance and more." />
      <section className="section">
        <div className="container grid grid-2">
          {articles.map((a) => (
            <Link href={`/insights/${a.slug}`} className="card" key={a.slug} style={{ color: "inherit", textDecoration: "none" }}>
              <div className="icon-badge"><Icon name="book" size={24} /></div>
              <div style={{ fontSize: ".85rem", color: "var(--muted)", marginBottom: 6 }}>{fmt(a.date)}</div>
              <h3 style={{ fontSize: "1.4rem" }}>{a.title}</h3>
              <p style={{ marginBottom: 18 }}>{a.excerpt}</p>
              <span className="link-arrow" style={{ color: "var(--blue)" }}>Read article <Icon name="arrow" size={18} /></span>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
