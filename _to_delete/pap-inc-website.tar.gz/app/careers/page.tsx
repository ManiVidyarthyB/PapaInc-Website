import type { Metadata } from "next";
import { site } from "@/lib/content";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";

export const metadata: Metadata = { title: "Careers" };

const perks = [
  { icon: "chart", title: "Grow professionally", text: "Opportunities for personal and professional development at every stage." },
  { icon: "gauge", title: "Flexible careers", text: "Career options that adapt to where you are and where you want to go." },
  { icon: "users", title: "Collaborative team", text: "Work side by side with experienced consultants, accountants and technologists." },
];

export default function Careers() {
  return (
    <>
      <PageHero title="Find Your Career with Paragon" crumb="Careers"
        intro="Paragon offers opportunities for personal and professional development, flexible career options, and a collaborative team environment.">
        <p style={{ marginTop: 28 }}>
          <a href={site.careersUrl} className="btn" target="_blank" rel="noopener noreferrer">View Positions at PAP <Icon name="arrow" size={18} /></a>
        </p>
      </PageHero>
      <section className="section">
        <div className="container grid grid-3">
          {perks.map((p) => (
            <div className="card" key={p.title}>
              <div className="icon-badge"><Icon name={p.icon} size={26} /></div>
              <h3>{p.title}</h3>
              <p>{p.text}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="section section-soft">
        <div className="container center">
          <h2>Ready to join the team?</h2>
          <p className="lead">Browse current openings and apply online.</p>
          <a href={site.careersUrl} className="btn" target="_blank" rel="noopener noreferrer">View Open Positions</a>
        </div>
      </section>
    </>
  );
}
