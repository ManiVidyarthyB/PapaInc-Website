import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/content";

export const metadata: Metadata = { title: "Privacy Policy" };

// NOTE: Placeholder copy. Replace with the privacy policy from your current site / legal counsel.
export default function Page() {
  return (
    <LegalPage title="Privacy Policy">
      <p><em>Last updated: {new Date().getFullYear()}</em></p>
      <p>{site.name} (&ldquo;Paragon,&rdquo; &ldquo;we,&rdquo; &ldquo;us&rdquo;) respects your privacy. This policy describes how we collect, use and protect information you provide through this website.</p>
      <h2>Information we collect</h2>
      <p>We collect information you submit voluntarily — such as your name, email address and business URL when you use our contact form — and basic technical data such as browser type and pages visited.</p>
      <h2>How we use information</h2>
      <p>We use your information to respond to inquiries, provide requested services, and improve our website. We do not sell your personal information.</p>
      <h2>Contact</h2>
      <p>Questions about this policy can be directed to us at {site.address.line1}, {site.address.line2}, or by phone at {site.phone}.</p>
    </LegalPage>
  );
}
