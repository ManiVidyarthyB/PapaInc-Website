import type { Metadata } from "next";
import IndustryPage from "@/components/IndustryPage";

export const metadata: Metadata = { title: "Government Services" };

export default function Page() {
  return (
    <IndustryPage
      title="Government Services"
      intro="Our government is facing an unprecedented time — and we're confident in its ability to recover."
      paragraphs={[
        "Uncertainty about what tomorrow may bring has left many communities anxious. We believe in the government's capacity to recover, and we see our role as a bridge connecting public and private service providers with the constituents they serve.",
        "Paragon builds on the methodologies government relies on to deliver services, payments and other assistance. We support state and local governments, municipalities and nonprofits as they work together to stabilize their communities and return to pre-pandemic conditions.",
      ]}
      listTitle="How we support the public sector"
      list={[
        "Public Assistance grant preparedness & compliance",
        "Project closeout QA/QC reviews",
        "Performance audits of government programs",
        "Grant administration and compliance monitoring",
      ]}
      variant={0}
    />
  );
}
