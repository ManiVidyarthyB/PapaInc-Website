import type { Metadata } from "next";
import Link from "next/link";
import { helpWith, services } from "@/lib/content";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";
import CtaBand from "@/components/CtaBand";

export const metadata: Metadata = { title: "What We Do" };

export default function WhatWeDo() {
  return (
    <>
      <PageHero
        title="What We Do"
        intro="Our consultants and operational model are key to how Paragon ensures its clients' needs are met. We pride ourselves on our value add — bringing fluidity and dependability to any project."
      />
      <section className="section">
        <div className="container">
          <div className="grid grid-2">
            {services.map((s) => (
              <div className="card" id={s.id} key={s.id} style={{ scrollMarginTop: 100 }}>
                <div className="icon-badge"><Icon name={s.icon} size={26} /></div>
                <h3 style={{ fontSize: "1.45rem" }}>{s.title}</h3>
                <p style={{ marginBottom: 18 }}>{s.text}</p>
                <Link href="/contact-us" className="link-arrow">Talk to an expert <Icon name="arrow" size={18} /></Link>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section section-soft">
        <div className="container">
          <div className="center" style={{ marginBottom: 40 }}>
            <span className="eyebrow">Engagements</span>
            <h2>How we typically help</h2>
          </div>
          <div className="grid grid-3">
            {helpWith.map((s) => (
              <div className="card" key={s.title}>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
