import type { Metadata } from "next";
import IndustryPage from "@/components/IndustryPage";

export const metadata: Metadata = { title: "Financial & Business Services" };

export default function Page() {
  return (
    <IndustryPage
      title="Financial & Business Services"
      intro="An industry reshaped by declining fee rates, increased regulation and digital transformation."
      paragraphs={[
        "A fluctuating economic landscape is affecting the profitability and long-term sustainability of financial service operations.",
        "Leaders are responding with new operating models, aggressive revenue management and cost control, mergers and acquisitions, integration and partnership strategies. Paragon brings the risk, transaction and finance expertise to help them execute.",
      ]}
      listTitle="Where we help"
      list={[
        "Internal audit and controls reviews",
        "Transaction due diligence",
        "Financial planning & analysis",
        "Regulatory and risk compliance",
      ]}
      variant={2}
    />
  );
}
