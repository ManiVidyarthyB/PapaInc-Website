import type { Metadata } from "next";
import { site } from "@/lib/content";
import PageHero from "@/components/PageHero";
import ContactForm from "@/components/ContactForm";
import Icon from "@/components/Icon";
import SocialIcon from "@/components/SocialIcon";

export const metadata: Metadata = { title: "Contact Us" };

export default function Contact() {
  const mapQuery = encodeURIComponent(`${site.address.line1}, ${site.address.line2}`);
  return (
    <>
      <PageHero title="Contact Us" crumb="Contact Us" eyebrow="Get Started Today"
        intro="Where does your business need more support? We offer a broad range of services and packages that can be customized to your needs. Send us a message today, and we can start you on a path to success." />
      <section className="section">
        <div className="container split" style={{ alignItems: "start" }}>
          <div>
            <h2>Drop us a line!</h2>
            <p style={{ color: "var(--muted)", marginBottom: 28 }}>We typically respond within one business day.</p>
            <ContactForm />
          </div>
          <div className="info-card">
            <h3>{site.name}</h3>
            <div className="info-row"><Icon name="pin" /><div>{site.address.line1}<br />{site.address.line2}<br />{site.address.country}</div></div>
            <div className="info-row"><Icon name="phone" /><a href={`tel:${site.phone.replace(/-/g, "")}`}>{site.phone}</a></div>
            <div className="socials">
              {site.social.map((s) => (
                <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.label}><SocialIcon name={s.label} /></a>
              ))}
            </div>
            <iframe title="Office location map" src={`https://www.google.com/maps?q=${mapQuery}&output=embed`}
              style={{ border: 0, width: "100%", height: 240, borderRadius: 12, marginTop: 28 }} loading="lazy" />
          </div>
        </div>
      </section>
    </>
  );
}
