import type { Metadata } from "next";
import IndustryPage from "@/components/IndustryPage";

export const metadata: Metadata = { title: "Healthcare Services" };

export default function Page() {
  return (
    <IndustryPage
      title="Healthcare Services"
      intro="One of the most dynamic and fastest-changing industries in the United States."
      paragraphs={[
        "As Generation X and Baby Boomers move into retirement, demand is rising for clinical therapies, pharmaceutical solutions, telemedicine and the technologies that support them — reshaping the U.S. healthcare landscape.",
        "Those opportunities come with real risk, including fraud, cybersecurity threats and non-compliance. Paragon helps healthcare leaders pursue growth while keeping those risks in check.",
      ]}
      listTitle="Strategies healthcare leaders are pursuing"
      list={[
        "New clinical and operating models",
        "Revenue management and cost control",
        "Mergers and acquisitions",
        "Horizontal and vertical integration",
        "Partnership strategies",
      ]}
      variant={1}
    />
  );
}
