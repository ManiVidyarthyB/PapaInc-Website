import type { Metadata } from "next";
import "@fontsource-variable/inter";
import "@fontsource/poppins/500.css";
import "@fontsource/poppins/600.css";
import "@fontsource/poppins/700.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://pap-inc.com"),
  title: { default: "Paragon Advisory Partners | Optimize Your Outlook", template: "%s | Paragon Advisory Partners" },
  description:
    "Nationwide professional services firm specializing in risk assurance, emergency management, transaction services, and accounting & finance.",
  openGraph: { siteName: "Paragon Advisory Partners", type: "website" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
