import Link from "next/link";
import { ceoQuote, helpWith, industries, values, whoWeAre } from "@/lib/content";
import Icon from "@/components/Icon";
import Visual from "@/components/Visual";
import CtaBand from "@/components/CtaBand";

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container">
          <div className="hero-inner">
            <span className="eyebrow" style={{ color: "#8fb6ff" }}>Paragon Advisory Partners</span>
            <h1>Optimize Your Outlook</h1>
            <p>
              Things are more uncertain than ever. Paragon understands the need for proven professionals to combat the
              &ldquo;New Normal.&rdquo;
            </p>
            <div className="actions">
              <Link href="/contact-us" className="btn">Get Started <Icon name="arrow" size={18} /></Link>
              <Link href="/what-we-do" className="btn btn-outline">What We Do</Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container split">
          <div>
            <span className="eyebrow">Who We Are</span>
            <h2>Solution-oriented experts, ready when you need them</h2>
            <p className="lead">{whoWeAre}</p>
            <div className="stat-row">
              <div className="stat"><strong>Nationwide</strong><span>Professional services</span></div>
              <div className="stat"><strong>MWBE &amp; DBE</strong><span>Certified business</span></div>
              <div className="stat"><strong>4 Practices</strong><span>One trusted partner</span></div>
            </div>
            <p style={{ marginTop: 28 }}><Link href="/about" className="link-arrow">More about Paragon <Icon name="arrow" size={18} /></Link></p>
          </div>
          <Visual variant={0} />
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="center" style={{ marginBottom: 48 }}>
            <span className="eyebrow">Our Expertise</span>
            <h2>We Can Help You With</h2>
          </div>
          <div className="grid grid-3">
            {helpWith.map((s) => (
              <div className="card" key={s.title}>
                <div className="icon-badge"><Icon name={s.icon} size={26} /></div>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div style={{ marginBottom: 44 }}>
            <span className="eyebrow">Industries</span>
            <h2>Where we make an impact</h2>
          </div>
          <div className="grid grid-3">
            {industries.map((ind, i) => (
              <Link href={ind.href} key={ind.title} className={`industry tone-${ind.tone}`}>
                <span className="industry-num">0{i + 1}</span>
                <h3>{ind.title}</h3>
                <p>{ind.text}</p>
                <span className="link-arrow">Learn more <Icon name="arrow" size={18} /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section section-dark">
        <div className="container">
          <div className="center" style={{ marginBottom: 48 }}>
            <span className="eyebrow">Our Values</span>
            <h2>Why Partner with Us</h2>
          </div>
          <div className="grid grid-5">
            {values.map((v, i) => (
              <div className="value" key={v.title}>
                <div className="num">0{i + 1}</div>
                <h3>{v.title}</h3>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container quote">
          <div className="mark">&ldquo;</div>
          <blockquote>{ceoQuote.quote}</blockquote>
          <cite><strong>{ceoQuote.name}</strong><span>{ceoQuote.title}</span></cite>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
