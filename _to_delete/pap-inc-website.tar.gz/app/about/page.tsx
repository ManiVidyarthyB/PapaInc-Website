import type { Metadata } from "next";
import { ceoQuote, values } from "@/lib/content";
import PageHero from "@/components/PageHero";
import Icon from "@/components/Icon";
import Visual from "@/components/Visual";
import CtaBand from "@/components/CtaBand";

export const metadata: Metadata = { title: "About Us" };

export default function About() {
  return (
    <>
      <PageHero title="About Us" crumb="About" intro="A community of professionals who are always ready to create solutions." />
      <section className="section">
        <div className="container split">
          <div>
            <span className="eyebrow">Our Consultants</span>
            <h2>Strategy and execution for complex challenges</h2>
            <p className="lead">
              Our team solves complex business challenges through strategy and execution, drawing on extensive industry
              experience to devise practical solutions across a range of functional areas.
            </p>
            <ul className="checklist" style={{ marginTop: 20 }}>
              <li>Internal Audit</li>
              <li>IT Consulting</li>
              <li>Risk Compliance</li>
              <li>Mergers and Acquisitions</li>
            </ul>
          </div>
          <Visual variant={1} />
        </div>
      </section>
      <section className="section section-soft">
        <div className="container grid grid-2">
          <div className="card">
            <div className="icon-badge"><Icon name="users" size={26} /></div>
            <h3 style={{ fontSize: "1.45rem" }}>Our Background</h3>
            <p>
              We value a diverse workforce. Our team members hold advanced degrees and professional certifications, and
              they benefit every day from working alongside top-tier talent in the consulting arena.
            </p>
          </div>
          <div className="card">
            <div className="icon-badge"><Icon name="target" size={26} /></div>
            <h3 style={{ fontSize: "1.45rem" }}>Our Mission</h3>
            <p>
              To foster a community of professionals who are always ready to create solutions tailored to each
              client&apos;s needs — and to keep pushing boundaries with innovative approaches.
            </p>
          </div>
        </div>
      </section>
      <section className="section section-dark">
        <div className="container">
          <div className="center" style={{ marginBottom: 40 }}>
            <span className="eyebrow">Core Values</span>
            <h2>What guides our work</h2>
          </div>
          <div className="grid grid-5">
            {values.map((v, i) => (
              <div className="value" key={v.title}>
                <div className="num">0{i + 1}</div>
                <h3>{v.title}</h3>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container quote">
          <div className="mark">&ldquo;</div>
          <blockquote>{ceoQuote.quote}</blockquote>
          <cite><strong>{ceoQuote.name}</strong><span>{ceoQuote.title}</span></cite>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
