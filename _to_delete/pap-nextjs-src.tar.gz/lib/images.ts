// All images used on the site, in one place.
//
// "own" images are files Paragon uploaded to its GoDaddy site.
// "stock" images come from GoDaddy's built-in stock library, which is licensed
// for use on GoDaddy-hosted sites only — replace those with your own licensed
// photos before cancelling GoDaddy hosting.
//
// To self-host any image: download it into /public/images and swap the URL for
// "/images/<file>".

const OWN = "https://img1.wsimg.com/isteam/ip/69c1d22b-e611-4d23-9534-d2b552b371a8";
const STOCK = "https://img1.wsimg.com/isteam/stock";

export const img = {
  logo: `${OWN}/Logo2.png/:/rs=w:263,h:150,cg:true,m/cr=w:263,h:150/qt=q:95`,

  // Home
  heroBuildings: `${OWN}/Strategic%20Partners.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:1280,h:960,cg:true`,
  whoWeAre: `${OWN}/Quality%20Home%20Page.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:1280,h:960,cg:true`,
  capitol: `${OWN}/Capitol-Hill.jpg/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  healthcare: `${OWN}/healthcare.jpg/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  transaction: `${OWN}/Transaction%20Services.jpg/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  help1: `${STOCK}/11253/:/rs=w:776,h:388,cg:true,m/cr=w:776,h:388`,
  help2: `${STOCK}/12135/:/rs=w:776,h:388,cg:true,m/cr=w:776,h:388`,
  help3: `${STOCK}/12338/:/rs=w:776,h:388,cg:true,m/cr=w:776,h:388`,
  help4: `${STOCK}/12828/:/rs=w:776,h:388,cg:true,m/cr=w:776,h:388`,
  help5: `${STOCK}/1583/:/cr=t:18.75%25,l:8.33%25,w:83.33%25,h:62.5%25/rs=w:776,h:388,cg:true,m`,
  help6: `${STOCK}/11252/:/rs=w:776,h:388,cg:true,m/cr=w:776,h:388`,

  // What We Do
  riskAssurance: `${STOCK}/uNpAN1eWxYfkNzJ7r/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  emergencyCircle: `${OWN}/Emergency%20Management.jpg/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  transactionCircle: `${STOCK}/29GnJkb/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,
  accountingCircle: `${STOCK}/423/:/rs=w:730,h:730,cg:true,m/cr=w:730,h:730`,

  // Who We Serve
  govColumns: `${OWN}/Government%20Columns%20Light.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  finance: `${OWN}/Finance.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  corps: `${OWN}/Corps.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,

  // About
  about1: `${STOCK}/11252/:/rs=w:1200,h:600,cg:true,m/cr=w:1200,h:600`,
  about2: `${STOCK}/11253/:/rs=w:1200,h:600,cg:true,m/cr=w:1200,h:600`,
  about3: `${STOCK}/12135/:/rs=w:1200,h:600,cg:true,m/cr=w:1200,h:600`,

  // Contact
  contact: `${OWN}/Industry_Technology_compressed-600x600.jpg/:/rs=w:984,h:984,cg:true,m/cr=w:984,h:984`,

  // Industry / service detail pages
  healthcareBanner: `${OWN}/industry_healthcare-still-1920x730.png/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  financialBanner: `${OWN}/Industry_Financial-Services_compressed-1920x73.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  riskBanner: `${OWN}/Risk%20Assurance.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  emergencyBanner: `${OWN}/Industry_Business-Services_offset_555811_compr.jpg/:/rs=w:800,cg:true,m`,
  dealBanner: `${STOCK}/293/:/rs=w:800,cg:true,m`,

  // Insights articles
  winners: `${OWN}/winners.jfif/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:800,cg:true`,
  dr0: `${OWN}/who-we-serve-5-945x645.jpg/:/cr=t:0%25,l:0%25,w:100%25,h:100%25/rs=w:1200,h:600,cg:true`,
  dr1: `${OWN}/Picture1.png/:/cr=t:13.31%25,l:0%25,w:100%25,h:72.13%25/rs=w:1200,h:600,cg:true`,
  dr2: `${OWN}/Picture2.png/:/cr=t:0%25,l:0%25,w:100%25,h:75.14%25/rs=w:1200,h:600,cg:true`,
  dr3: `${OWN}/Picture3.jpg/:/cr=t:8.54%25,l:0%25,w:100%25,h:72.78%25/rs=w:1200,h:600,cg:true`,
  dr4: `${OWN}/Picture4.png/:/cr=t:0%25,l:0%25,w:100%25,h:64.94%25/rs=w:1200,h:600,cg:true`,
  dr5: `${STOCK}/opPDWdB/:/cr=t:0%25,l:33.98%25,w:35.77%25,h:26.6%25/rs=w:1200,h:600,cg:true,m`,
};
