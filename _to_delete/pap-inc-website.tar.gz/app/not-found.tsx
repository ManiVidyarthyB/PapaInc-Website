import Link from "next/link";

export default function NotFound() {
  return (
    <section className="section center">
      <div className="container">
        <h1>Page not found</h1>
        <p className="lead">The page you&apos;re looking for doesn&apos;t exist or has moved.</p>
        <Link href="/" className="btn">Back to Home</Link>
      </div>
    </section>
  );
}
